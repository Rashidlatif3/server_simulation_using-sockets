import socket
import os
import threading
import urllib.parse
import mimetypes

HOST = '127.0.0.1'  
PORT = 8080        
ROOT_DIR = 'www'    

if not os.path.exists(ROOT_DIR):
    os.makedirs(ROOT_DIR)

def parse_form_data(data, content_type):
    """
    Parses form data from a POST request.
    Supports both application/x-www-form-urlencoded and multipart/form-data (for file uploads).
    """
    parsed_data = {}
    files = {}

    if "multipart/form-data" in content_type:
        boundary = content_type.split("boundary=")[-1]
        parts = data.split("--" + boundary)

        for part in parts:
            if "Content-Disposition" in part:
                lines = part.strip().split("\r\n")
                disposition = lines[0]

                # Extract name
                name_match = re.search(r'name="([^"]+)"', disposition)
                if name_match:
                    field_name = name_match.group(1)

                    # Check if it's a file
                    if 'filename="' in disposition:
                        filename_match = re.search(r'filename="([^"]+)"', disposition)
                        if filename_match:
                            filename = filename_match.group(1)
                            file_content = "\r\n".join(lines[2:])  # File content starts from the third line
                            files[field_name] = {"filename": filename, "content": file_content}
                    else:
                        field_value = lines[2]  # Regular text field
                        parsed_data[field_name] = field_value

    else:
        pairs = data.split('&')
        for pair in pairs:
            if '=' in pair:
                key, value = pair.split('=', 1)
                parsed_data[key] = urllib.parse.unquote_plus(value)
            else:
                parsed_data[pair] = ''

    return parsed_data, files


def handle_client(client_socket):
    """
    Handle incoming client requests.
    """
    try:
        request_data = client_socket.recv(4096).decode('utf-8', errors='ignore')
        print(f"Received request:\n{request_data}")

        request_lines = request_data.splitlines()
        if len(request_lines) == 0:
            client_socket.close()
            return

        request_parts = request_lines[0].split()
        if len(request_parts) < 2:
            client_socket.close()
            return

        request_method, request_path = request_parts[:2]

        if request_method == 'GET':
            file_path = os.path.join(ROOT_DIR, request_path.lstrip('/'))
            if os.path.isdir(file_path):
                file_path = os.path.join(file_path, 'index.html')

            if not os.path.exists(file_path):
                response = "HTTP/1.1 404 Not Found\r\n\r\nFile Not Found"
                client_socket.send(response.encode('utf-8'))
                client_socket.close()
                return

            with open(file_path, 'rb') as file:
                file_content = file.read()

            content_type = mimetypes.guess_type(file_path)[0] or "application/octet-stream"

            response_headers = (
                "HTTP/1.1 200 OK\r\n"
                f"Content-Length: {len(file_content)}\r\n"
                f"Content-Type: {content_type}\r\n\r\n"
            )
            client_socket.send(response_headers.encode('utf-8') + file_content)

        elif request_method == 'POST' and request_path == '/submit':
            content_length = 0
            content_type = ""

            for line in request_lines:
                if line.startswith('Content-Length:'):
                    content_length = int(line.split(':')[1].strip())
                if line.startswith('Content-Type:'):
                    content_type = line.split(':', 1)[1].strip()

            request_body = request_data.split("\r\n\r\n")[-1]
            while len(request_body) < content_length:
                request_body += client_socket.recv(content_length - len(request_body)).decode('utf-8', errors='ignore')

            parsed_data, files = parse_form_data(request_body, content_type)

            response_body = "<h1>Form Submitted Successfully!</h1>"

            if 'name' in parsed_data:
                response_body += f"<p><b>Name:</b> {parsed_data.get('name', 'N/A')}</p>"
            if 'email' in parsed_data:
                response_body += f"<p><b>Email:</b> {parsed_data.get('email', 'N/A')}</p>"
            response_body += f"<p><b>Message:</b> {parsed_data.get('message', 'N/A')}</p>"

            # Handle file uploads
            if files:
                response_body += "<h2>Uploaded Files</h2><ul>"
                for field, file_info in files.items():
                    filename = file_info['filename']
                    file_content = file_info['content']

                    # Save file to server
                    save_path = os.path.join(ROOT_DIR, filename)
                    with open(save_path, 'w') as f:
                        f.write(file_content)

                    response_body += f"<li>{filename} (Saved successfully)</li>"
                response_body += "</ul>"

            response_body += '<br><br><a href="/">Go Back</a>'

            response = (
                "HTTP/1.1 200 OK\r\n"
                "Content-Type: text/html\r\n\r\n"
                f"{response_body}"
            )
            client_socket.send(response.encode('utf-8'))

        else:
            response = "HTTP/1.1 405 Method Not Allowed\r\n\r\n"
            client_socket.send(response.encode('utf-8'))

    except Exception as e:
        print(f"Error handling client request: {e}")
    finally:
        client_socket.close()


def start_server():
    """
    Start the web server and listen for incoming connections.
    """
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((HOST, PORT))
    server_socket.listen(5)
    print(f"Server started on http://{HOST}:{PORT}")
    print("Waiting for connections...")

    while True:
        client_socket, client_address = server_socket.accept()
        print(f"New connection from {client_address}")

        client_thread = threading.Thread(target=handle_client, args=(client_socket,))
        client_thread.start()


if __name__ == "__main__":
    start_server()
